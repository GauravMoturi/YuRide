package com.yuride.entity;

public enum Status {
    WAITING,
    APPROVED,
    REJECTED
}
