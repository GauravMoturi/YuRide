package com.yuride.controller;

import com.yuride.service.FileUploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class FileUploadController {

    @Autowired
    private FileUploadService fileUploadService;

    @PostMapping("/users/{userId}/uploadDriverLicense")
    public String uploadDriverLicense(@RequestPart("driverLicense") MultipartFile file,
                                      @PathVariable Long userId) {
        return fileUploadService.uploadDriverLicense(userId, file);
    }

    @PostMapping("/users/{userId}/uploadPhotoID")
    public String uploadPhotoID(@RequestPart("photoID") MultipartFile file,
                                @PathVariable Long userId) {
        return fileUploadService.uploadPhotoID(userId, file);
    }

    @PostMapping("/users/{userId}/uploadVehicleInsurance")
    public String uploadVehicleInsurance(@RequestPart("vehicleInsurance") MultipartFile file,
                                         @PathVariable Long userId) {
        return fileUploadService.uploadVehicleInsurance(userId, file);
    }
}
