package com.yuride.service.impl;

import com.yuride.entity.User;
import com.yuride.repository.UserRepository;
import com.yuride.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    @Override
    public User createUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public User updateUser(Long id, User user) {
        // Check if the user with the given ID exists
        User existingUser = userRepository.findById(id).orElse(null);
        
        if (existingUser != null) {
            // Update the fields you want from the request
            existingUser.setName(user.getName());
            existingUser.setLastName(user.getLastName());
            // Update other fields as needed
            
            // Save the updated user
            return userRepository.save(existingUser);
        } else {
            // Handle the case when the user with the given ID does not exist
            return null; // or throw an exception
        }
    }

    @Override
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }
}
