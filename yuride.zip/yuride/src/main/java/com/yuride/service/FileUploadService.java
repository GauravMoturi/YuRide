package com.yuride.service;

import org.springframework.web.multipart.MultipartFile;

public interface FileUploadService {

    String uploadDriverLicense(Long userId, MultipartFile file);

    String uploadPhotoID(Long userId, MultipartFile file);

    String uploadVehicleInsurance(Long userId, MultipartFile file);
}
