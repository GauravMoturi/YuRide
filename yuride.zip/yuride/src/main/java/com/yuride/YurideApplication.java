package com.yuride;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YurideApplication {

	public static void main(String[] args) {
		SpringApplication.run(YurideApplication.class, args);
	}

}
