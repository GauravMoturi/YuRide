package com.yuride.repository;

import com.yuride.entity.PhotoID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PhotoIDRepository extends JpaRepository<PhotoID, Long> {
    // Additional custom queries, if needed
}
