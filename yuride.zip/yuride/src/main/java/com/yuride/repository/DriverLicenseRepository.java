package com.yuride.repository;

import com.yuride.entity.DriverLicenseImage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DriverLicenseRepository extends JpaRepository<DriverLicenseImage, Long> {
    // Additional custom queries, if needed
}
