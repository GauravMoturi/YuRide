package com.yuride;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YurideApplicationTests {

	@Test
	void contextLoads() {
	}

}
